# Expert Designer · Toolskin v6 — Unified Pack

15 files · 220.4 KB

## Quick start

1. Drop `expert-designer/` into your project root.
2. Open `expert-designer/SKILL.md` — that's the entry point.
3. For Session 3.x integration, open `expert-designer/HANDOFF.md`.
4. Open `expert-designer/showcase.html` in a browser for the live demo.
5. Run `node expert-designer/scripts/audit-design.mjs <file.html>` to lint any page.

## File map
- `expert-designer/SKILL.md` — Agent entry point. Task classifier, four locked systems (color, type, space, shape), decision trees, ten hard guardrails, six-step workflow.
- `expert-designer/HANDOFF.md` — Integration handoff for Session 3.x agents. Alignment edits required (RULING 3, 5, 9), integration sequence, what the skill gives + does not cover.
- `expert-designer/references/01-foundation.md` — Color engine, three knobs (accent-h/s/l), ten surface presets, APCA gate, --ts-* namespace contract, WordPress/Enfold bridge.
- `expert-designer/references/02-typography.md` — The 1.200 modular ladder anchored at 16px. Line-heights and tracking per role. Heading/body/mono font picks. Hierarchy patterns.
- `expert-designer/references/03-layout-and-spacing.md` — 8pt grid + 4pt sub-grid. Container budgets. Three layout primitives (auto-fit, split, pinned-footer). Container queries. The "this won't break" test.
- `expert-designer/references/04-cards-and-containers.md` — Ten copy-paste card recipes (stat, feature, media, person, price, quote, action, list, spotlight, glass). Anatomy, dimensions, states, pitfalls.
- `expert-designer/references/05-awwwards-patterns.md` — Ten hero/section patterns from Awwwards canon. Each broken down to the ONE move that makes it great.
- `expert-designer/references/06-component-recipes.md` — Buttons, inputs, badges, chips, nav, footer, modal, toast. Full CSS, all states defined, accessibility notes.
- `expert-designer/scripts/generate-colors.js` — Deterministic color primitive builder. Dual-emits hex+OKLCH, runs APCA verification.
- `expert-designer/scripts/audit-design.mjs` — HTML linter. Catches hardcoded hex, !important, unsafe 1fr grids, banned fonts, off-ladder sizes. Exits 1 on hard fail.
- `expert-designer/scripts/health-check.sh` — Skill structure verifier. Checks files, scripts, templates, color engine.
- `expert-designer/scripts/scaffold-component.sh` — Drops a working recipe HTML into the cwd, ready to iterate on.
- `expert-designer/templates/tokens.css` — The complete --ts-* contract in cascade layers (reset / tokens / base / components / utilities).
- `expert-designer/templates/seed-page.html` — Clean Toolskin starter — hero + features grid + CTA card.
- `expert-designer/showcase.html` — Visual proof. Live themeable hero, HSL accent sliders, type ladder, surface swatches, live card recipes.
